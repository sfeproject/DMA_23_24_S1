package radio.com.myapplication;

public class Bureau {
    private int id;
    private String nom;
    private String cp;
    private double lat;
    private double lng;

    public Bureau(int id, String nom, String cp, double lat, double lng) {
        this.id = id;
        this.nom = nom;
        this.cp = cp;
        this.lat = lat;
        this.lng = lng;
    }

    public int getId() {
        return id;
    }

    public String getNom() {
        return nom;
    }

    public String getCp() {
        return cp;
    }

    public double getLat() {
        return lat;
    }

    public double getLng() {
        return lng;
    }

    @Override
    public String toString() {
        return nom + " - " + cp ;
    }
}